tar -cvf hw1.tar main.cpp Process.cpp Memory.h Memory.cpp CPU.cpp Sysgen.cpp
